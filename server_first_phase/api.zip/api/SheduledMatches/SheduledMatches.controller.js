'use strict';
var _ = require('lodash');
var Sheduledmatches = require('./SheduledMatches.model');
//var Events = require('../TournamentEvents/TournamentEvents.model');
//var Courts = require('../Courts/Courts.model');
//var Formates = require('../TournamentFormats/TournamentFormats.model');
//var Scoreboard = require('../ScoreBoard/ScoreBoard.model');
var User = require('../Users/Users.model');
var EventPlayerList = require('../EventPlayerList/EventPlayerList.model');
var auth = require('../../auth/auth.service');

// Get list of sheduledmatchess
exports.index = function(req, res) {
  Sheduledmatches.find()
  .populate({path:'CourtId', select:"_id CourtName CourtNo"})
  .populate({path:'EventId'})
  .populate({path:'FormatId'})
  .populate({path:'TeamA_Player1_Id', select:'FirstName LastName _id'})
  .populate({path:'TeamA_Player2_Id', select:'FirstName LastName _id'})
  .populate({path:'TeamB_Player1_Id', select:'FirstName LastName _id'})
  .populate({path:'TeamB_Player2_Id', select:'FirstName LastName _id'})
  .populate({path:'RefereeId', select:'FirstName LastName _id'})
  .lean()
  .exec(function (err, sheduledmatchess) {
    if(err) { return handleError(res, err); }
    if(sheduledmatchess.length > 0){
      Sheduledmatches.populate(sheduledmatchess, {
          path: 'EventId.EventId',
          model: 'MasterEvents'
        }, function(err, cars) {
          if(err) return callback(err);
          Sheduledmatches.populate(cars, {
            path: "FormatId.FormatId",
            model: 'MasterFormats',
            select: 'FormatName _id'
          }, function(err, matchdetails){
            if(err){ return handleError(res, err); }
            var arr = [];
            matchdetails.forEach(function(element, index){
              var temp = {};
              temp._id = element._id;
              temp.Time = element.Time;
              temp.courtId = element.CourtId['_id'];
              temp.court = element.CourtId['CourtName'];
              temp.courtNumber = element.CourtId['CourtNumber'];
              temp.EventId= element.EventId['_id'];
              temp.EventName = element.EventId.EventId['EventName'];
              temp.Event = element.EventId.EventId['EventType'];
              temp.GameFormat = element.FormatId.FormatId['FormatName'];
              temp.GameFormatId = element.FormatId['_id'];
              temp.Referee = element.RefereeId['FirstName']+""+element.RefereeId['LastName'];
              temp.RefereeId = element.RefereeId['_id'];
              temp.MatchStatus = element.MatchStatus;
              var t1 = [];
              var t2 = [];
              var taobj1 = {};
              taobj1.Name = element.TeamA_Player1_Id['FirstName']+""+element.TeamA_Player1_Id['LastName'];
              taobj1.id = element.TeamA_Player1_Id['_id'];
              var tbobj1 = {};
              tbobj1.Name = element.TeamB_Player1_Id['FirstName']+""+element.TeamB_Player1_Id['LastName'];
              tbobj1.id = element.TeamB_Player1_Id['_id'];
              t1.push(taobj1);
              t2.push(tbobj1);
              var taobj2 = {};
              var tbobj2 = {};
              if(element.TeamA_Player2_Id !== undefined){
                taobj2.Name = element.TeamA_Player2_Id['FirstName']+""+element.TeamA_Player2_Id['LastName'];
                taobj2.id = element.TeamA_Player2_Id['_id'];
                t1.push(taobj2);
              }
              if(element.TeamB_Player2_Id !== undefined){
                tbobj2.Name = element.TeamB_Player2_Id['FirstName']+""+element.TeamB_Player2_Id['LastName'];
                tbobj2.id = element.TeamB_Player2_Id['_id'];
                t2.push(tbobj2);
              }          
              temp.Team1 = {};
              temp.Team1.Players = t1;
              temp.Team2 = {};
              temp.Team2.Players = t2;
              arr.push(temp);
            })
            return res.status(200).json(arr);
          })          
        });
    }else{
      res.status(200).json("no matches found");
    }
  });
};

// Get a single sheduledmatches
exports.show = function(req, res) {
  Sheduledmatches.findById(req.params.id, function (err, sheduledmatches) {
    if(err) { return handleError(res, err); }
    if(!sheduledmatches) { return res.status(404).send('Not Found'); }
    return res.json(sheduledmatches);
  });
};

// Creates a new sheduledmatches in the DB.
exports.create = function(req, res) {
  req.body.AdminId = req.user._id;
  req.body.TournamentId = req.user._id;  
  req.body.RefereeName = req.body.RefereeName.split(" ").join('');
  //rand key for referee name
  req.body.RefereePassword = req.body.RefereeName.split(' ').join('')+req.body.CourtNo;
  Sheduledmatches.create(req.body, function(err, sheduledmatches) {
    if(err) { return handleError(res, err); }
    Sheduledmatches.find({_id: sheduledmatches._id})
    .populate({path:'CourtId', select:"_id CourtName CourtNo"})
    .populate({path:'EventId', select:'EventName EventType'})
    .populate({path:'FormatId', select:'FormateName twopointse'})
    .populate({path:'TeamA_Player1_Id', select:'FirstName LastName _id'})
    .populate({path:'TeamA_Player2_Id', select:'FirstName LastName _id'})
    .populate({path:'TeamB_Player1_Id', select:'FirstName LastName _id'})
    .populate({path:'TeamB_Player2_Id', select:'FirstName LastName _id'})
    .populate({path:'RefereeId', select:'FirstName LastName _id'})
    .lean()
    .exec(function(err, sheduledobj){
      if(err){ return handleError(res, err); }
      if(sheduledobj.length > 0){
        var temp = {};
        var arr = [];
        sheduledobj.forEach(function(element, index){
          temp._id = element._id;
          temp.Time = element.Time;
          temp.courtId = element.CourtId['_id'];
          temp.court = element.CourtId['CourtName'];
          temp.courtNumber = element.CourtId['CourtNumber'];
          temp.EventId= element.EventId['_id'];
          temp.EventName = element.EventId['EventName'];
          temp.Event = element.EventId['EventType'];
          temp.GameFormat = element.FormatId['FormateName'];
          temp.GameFormatId = element.FormatId['_id'];
          temp.twopointse = element.FormatId['twopointse'];
          temp.Referee = element.RefereeId['FirstName']+""+element.RefereeId['LastName'];
          temp.RefereeId = element.RefereeId['_id'];
          temp.MatchStatus = element.MatchStatus;
          var t1 = [];
          var t2 = [];
          var taobj1 = {};
          taobj1.Name = element.TeamA_Player1_Id['FirstName']+""+element.TeamA_Player1_Id['LastName'];
          taobj1.id = element.TeamA_Player1_Id['_id'];
          var tbobj1 = {};
          tbobj1.Name = element.TeamB_Player1_Id['FirstName']+""+element.TeamB_Player1_Id['LastName'];
          tbobj1.id = element.TeamB_Player1_Id['_id'];
          t1.push(taobj1);
          t2.push(tbobj1);
          var taobj2 = {};
          var tbobj2 = {};
          if(element.TeamA_Player2_Id !== undefined){
            taobj2.Name = element.TeamA_Player2_Id['FirstName']+""+element.TeamA_Player2_Id['LastName'];
            taobj2.id = element.TeamA_Player2_Id['_id'];
            t1.push(taobj2);
          }
          if(element.TeamB_Player2_Id !== undefined){
            tbobj2.Name = element.TeamB_Player2_Id['FirstName']+""+element.TeamB_Player2_Id['LastName'];
            tbobj2.id = element.TeamB_Player2_Id['_id'];
            t2.push(tbobj2);
          }          
          temp.Team1 = {};
          temp.Team1.Players = t1;
          temp.Team2 = {};
          temp.Team2.Players = t2;
          arr.push(temp);
        })
        return res.status(201).json(arr);
      }else{
        res.status(200).json("no match's are scheduled at !");
      }
    })
  });
};

//getting event name formate name 
function sheduledmatchdetails(req, res, obj, callback){

}

// Updates an existing sheduledmatches in the DB.
exports.update = function(req, res) {
  if(req.body._id) { delete req.body._id; }
  Sheduledmatches.findById(req.params.id, function (err, sheduledmatches) {
    if (err) { return handleError(res, err); }
    if(!sheduledmatches) { return res.status(404).send('Not Found'); }
    var updated = _.merge(sheduledmatches, req.body);
    updated.markModified('ScoreCard');
    updated.markModified('FirstServe');
    updated.save(function (err, data) {
      if (err) { return handleError(res, err); }
      Sheduledmatches.find({_id: req.params.id, Status: true})
      .populate({path:'CourtId', select:"_id CourtName CourtNo"})
      .populate({path:'EventId', select:'EventName EventType'})
      .populate({path:'FormatId', select:'FormateName ScoreCard twopointse'})
      .populate({path:'TeamAPlayer1Id', select:'Served FirstName _id'})
      .populate({path:'TeamAPlayer2Id', select:'Served FirstName _id'})
      .populate({path:'TeamBPlayer1Id', select:'Served FirstName _id'})
      .populate({path:'TeamBPlayer2Id', select:'Served FirstName _id'})
      .populate({path:'RefereeId', select:'FirstName _id'})
      .lean()
      .exec(function(err, matchobj){
        if(err){ return handleError(res, err); }
        if(matchobj.length > 0){
          var temp = {};
          temp._id = matchobj[0]._id;
          temp.Time = matchobj[0].Time;
          temp.courtId = matchobj[0].CourtId['_id'];
          temp.court = matchobj[0].CourtId['CourtName'];
          temp.courtNumber = matchobj[0].CourtId['CourtNo'];
          temp.EventId= matchobj[0].EventId['_id'];
          temp.EventName = matchobj[0].EventId['EventName'];
          temp.Event = matchobj[0].EventId['EventType'];
          temp.GameFormat = matchobj[0].FormatId['FormateName'];
          temp.GameFormatId = matchobj[0].FormatId['_id'];
          temp.twopointse = matchobj[0].FormatId['twopointse'];
          temp.Referee = matchobj[0].RefereeId['FirstName'];
          temp.RefereeId = matchobj[0].RefereeId['_id'];
          temp.MatchStatus = matchobj[0].MatchStatus;
          temp.GameStatus = matchobj[0].GameStatus;
          if(matchobj[0].FirstServe !== undefined){
            temp.FirstServe = matchobj[0].FirstServe;
            temp.ScoreCard = matchobj[0].ScoreCard;
          }else{
            temp.ScoreCard = matchobj[0].FormatId['ScoreCard'];
          }
          var t1 = [];
          var t2 = [];
          var taobj1 = {};
          taobj1.Name = matchobj[0].TeamAPlayer1Id['FirstName'];
          taobj1.id = matchobj[0].TeamAPlayer1Id['_id'];
          taobj1.Served = matchobj[0].TeamAPlayer1Id['Served'];
          var tbobj1 = {};
          tbobj1.Name = matchobj[0].TeamBPlayer1Id['FirstName'];
          tbobj1.id = matchobj[0].TeamBPlayer1Id['_id'];
          tbobj1.Served = matchobj[0].TeamBPlayer1Id['Served'];
          t1.push(taobj1);
          t2.push(tbobj1);
          var taobj2 = {};
          var tbobj2 = {};
          if(matchobj[0].TeamAPlayer2Id !== undefined){
            taobj2.Name = matchobj[0].TeamAPlayer2Id['FirstName'];
            taobj2.id = matchobj[0].TeamAPlayer2Id['_id'];
            taobj2.Served = matchobj[0].TeamAPlayer2Id['Served'];
            t1.push(taobj2);
          }
          if(matchobj[0].TeamBPlayer2Id !== undefined){
            tbobj2.Name = matchobj[0].TeamBPlayer2Id['FirstName'];
            tbobj2.id = matchobj[0].TeamBPlayer2Id['_id'];
            tbobj2.Served = matchobj[0].TeamBPlayer1Id['Served'];
            t2.push(tbobj2);
          }          
          temp.Team1 = {};
          temp.Team1.Players = t1;
          temp.Team2 = {};
          temp.Team2.Players = t2;
          res.status(200).send({"Matchs": temp});
        }else{
          res.status(200).send('no matches found');
        }
      })
    });
  });
};

// Deletes a sheduledmatches from the DB.
exports.destroy = function(req, res) {
  Sheduledmatches.findById(req.params.id, function (err, sheduledmatches) {
    if(err) { return handleError(res, err); }
    if(!sheduledmatches) { return res.status(404).send('Not Found'); }
    sheduledmatches.remove(function(err) {
      if(err) { return handleError(res, err); }
      return res.status(204).send('No Content');
    });
  });
};

function handleError(res, err) {
  return res.status(500).send(err);
}

//shedule match service
exports.matchsheduledfields = function(req, res){
  Courts.find({Selected: false})
  .lean()
  .exec(function(err, courtsobj){
    if(err){ return handleError(res, err); }
    if(courtsobj.length > 0){
      Formates.find({},{ScoreCard: 0, Status: 0, __v: 0},function(err, formatesobj){
        if(err){ return handleError(res, err); }
        if(formatesobj.length > 0){
          Events.find().lean().exec(function(err, eventsobj){
            if(err){ return handleError(res, err); }
            User.find({role:'Referee', Selected: false}, {_id: 1, FirstName: 1, Selected: 1}, function(err, refereeobj){
              if(err){ return handleError(res, err); }
              var arr = [];
              refereeobj.forEach(function(element, index){
                var refobj = {};
                refobj.RefereeId = element._id;
                refobj.RefereeName = element.FirstName;
                refobj.Selected = element.Selected;
                arr.push(refobj);
              })
              Sheduledmatches.find({TournamentId: req.user._id, Status: true})
              .populate({path:'CourtId', select:"_id CourtName CourtNo"})
              .populate({path:'EventId', select:'EventName EventType'})
              .populate({path:'FormatId', select:'FormateName twopointse'})
              .populate({path:'TeamAPlayer1Id', select:'FirstName _id'})
              .populate({path:'TeamAPlayer2Id', select:'FirstName _id'})
              .populate({path:'TeamBPlayer1Id', select:'FirstName _id'})
              .populate({path:'TeamBPlayer2Id', select:'FirstName _id'})
              .populate({path:'RefereeId', select:'FirstName _id'})
              .lean()
              .exec(function(err, sheduledmatchobj){
                if(err){ return handleError(res, err); }
                if(sheduledmatchobj.length > 0){
                  var matchsarr = [];
                  sheduledmatchobj.forEach(function(element, index){
                    var temp = {};
                    temp._id = element._id;
                    temp.Time = element.Time;
                    temp.courtId = element.CourtId['_id'];
                    temp.court = element.CourtId['CourtName'];
                    temp.courtNumber = element.CourtId['CourtNo'];
                    temp.EventId= element.EventId['_id'];
                    temp.EventName = element.EventId['EventName'];
                    temp.Event = element.EventId['EventType'];
                    temp.GameFormat = element.FormatId['FormateName'];
                    temp.GameFormatId = element.FormatId['_id'];
                    temp.twopointse = element.FormatId['twopointse'];
                    temp.Referee = element.RefereeId['FirstName'];
                    temp.RefereeId = element.RefereeId['_id'];
                    temp.MatchStatus = element.MatchStatus;
                    var t1 = [];
                    var t2 = [];
                    var taobj1 = {};
                    taobj1.Name = element.TeamAPlayer1Id['FirstName'];
                    taobj1.id = element.TeamAPlayer1Id['_id'];
                    var tbobj1 = {};
                    tbobj1.Name = element.TeamBPlayer1Id['FirstName'];
                    tbobj1.id = element.TeamBPlayer1Id['_id'];
                    t1.push(taobj1);
                    t2.push(tbobj1);
                    var taobj2 = {};
                    var tbobj2 = {};
                    if(element.TeamAPlayer2Id !== undefined){
                      taobj2.Name = element.TeamAPlayer2Id['FirstName'];
                      taobj2.id = element.TeamAPlayer2Id['_id'];
                      t1.push(taobj2);
                    }
                    if(element.TeamBPlayer2Id !== undefined){
                      tbobj2.Name = element.TeamBPlayer2Id['FirstName'];
                      tbobj2.id = element.TeamBPlayer2Id['_id'];
                      t2.push(tbobj2);
                    }          
                    temp.Team1 = {};
                    temp.Team1.Players = t1;
                    temp.Team2 = {};
                    temp.Team2.Players = t2;
                    matchsarr.push(temp);
                  })
                  var tempobj = {};
                  tempobj.Courts = courtsobj;
                  tempobj.Events = eventsobj;
                  tempobj.Formates = formatesobj;
                  tempobj.Referes = arr;
                  tempobj.Matchs = matchsarr;
                  res.status(200).send(tempobj);
                }else{
                  var obj = {};
                  obj.Courts = courtsobj;
                  obj.Events = eventsobj;
                  obj.Formates = formatesobj;
                  obj.Referes = arr;
                  obj.Matchs = [];
                  res.status(200).send(obj);
                }
              })
            })
          })
        }else{
          res.status(200).send("formates not found");
        }
      })
    }else{
      res.status(200).send("court not found");
    }
  })
}

//refree login
exports.refreelogin = function(req, res){
  Sheduledmatches.find({RefereeName: req.body.RefereeName, RefereePassword: req.body.RefereePassword, Status: true})
  .populate({path:'CourtId', select:"_id CourtName CourtNo"})
  .populate({path:'EventId', select:'EventName EventType'})
  .populate({path:'FormatId', select:'FormateName ScoreCard twopointse'})
  .populate({path:'TeamAPlayer1Id', select:'Served FirstName _id'})
  .populate({path:'TeamAPlayer2Id', select:'Served FirstName _id'})
  .populate({path:'TeamBPlayer1Id', select:'Served FirstName _id'})
  .populate({path:'TeamBPlayer2Id', select:'Served FirstName _id'})
  .populate({path:'RefereeId', select:'FirstName _id'})
  .lean()
  .exec(function(err, matchobj){
    if(err){ return handleError(res, err); }
    if(matchobj.length > 0){
      if(matchobj[0].MatchStatus == "Complete"){
        res.status(200).json("sorry this match has been completed");
      }else{
        var temp = {};
        temp._id = matchobj[0]._id;
        temp.Time = matchobj[0].Time;
        temp.courtId = matchobj[0].CourtId['_id'];
        temp.court = matchobj[0].CourtId['CourtName'];
        temp.courtNumber = matchobj[0].CourtId['CourtNo'];
        temp.EventId= matchobj[0].EventId['_id'];
        temp.EventName = matchobj[0].EventId['EventName'];
        temp.Event = matchobj[0].EventId['EventType'];
        temp.GameFormat = matchobj[0].FormatId['FormateName'];
        temp.GameFormatId = matchobj[0].FormatId['_id'];
        temp.twopointse = matchobj[0].FormatId['twopointse'];
        temp.Referee = matchobj[0].RefereeId['FirstName'];
        temp.RefereeId = matchobj[0].RefereeId['_id'];
        temp.MatchStatus = matchobj[0].MatchStatus;
        temp.GameStatus = matchobj[0].GameStatus;
        if(matchobj[0].FirstServe !== undefined){
          temp.FirstServe = matchobj[0].FirstServe;
          temp.ScoreCard = matchobj[0].ScoreCard;
        }else{
          temp.ScoreCard = matchobj[0].FormatId['ScoreCard'];
        }
        var t1 = [];
        var t2 = [];
        var taobj1 = {};
        taobj1.Name = matchobj[0].TeamAPlayer1Id['FirstName'];
        taobj1.id = matchobj[0].TeamAPlayer1Id['_id'];
        taobj1.Served = matchobj[0].TeamAPlayer1Id['Served'];
        var tbobj1 = {};
        tbobj1.Name = matchobj[0].TeamBPlayer1Id['FirstName'];
        tbobj1.id = matchobj[0].TeamBPlayer1Id['_id'];
        tbobj1.Served = matchobj[0].TeamBPlayer1Id['Served'];
        t1.push(taobj1);
        t2.push(tbobj1);
        var taobj2 = {};
        var tbobj2 = {};
        if(matchobj[0].TeamAPlayer2Id !== undefined){
          taobj2.Name = matchobj[0].TeamAPlayer2Id['FirstName'];
          taobj2.id = matchobj[0].TeamAPlayer2Id['_id'];
          taobj2.Served = matchobj[0].TeamAPlayer2Id['Served'];
          t1.push(taobj2);
        }
        if(matchobj[0].TeamBPlayer2Id !== undefined){
          tbobj2.Name = matchobj[0].TeamBPlayer2Id['FirstName'];
          tbobj2.id = matchobj[0].TeamBPlayer2Id['_id'];
          tbobj2.Served = matchobj[0].TeamBPlayer1Id['Served'];
          t2.push(tbobj2);
        }          
        temp.Team1 = {};
        temp.Team1.Players = t1;
        temp.Team2 = {};
        temp.Team2.Players = t2;
        var token = auth.signToken(matchobj[0].RefereeId, "Referee");
        res.status(200).send({"Matchs": temp, "Token": token, role: "Referee"});
      }
    }else{
      res.status(200).send('no matches found');
    }
  })
}

//spectator showing matches
exports.spectatormatchs = function(req, res){
  Sheduledmatches.find({Status: true})
  .populate({path:'CourtId', select:"_id CourtName CourtNo"})
  .populate({path:'EventId', select:'EventName EventType'})
  .populate({path:'FormatId', select:'FormateName ScoreCard twopointse'})
  .populate({path:'TeamAPlayer1Id', select:'Served FirstName _id'})
  .populate({path:'TeamAPlayer2Id', select:'Served FirstName _id'})
  .populate({path:'TeamBPlayer1Id', select:'Served FirstName _id'})
  .populate({path:'TeamBPlayer2Id', select:'Served FirstName _id'})
  .populate({path:'RefereeId', select:'FirstName _id'})
  .lean()
  .exec(function(err, sheduledmatchobj){
    if(err){ return handleError(res, err); }
    if(sheduledmatchobj.length > 0){
      var matchsarr = [];
      sheduledmatchobj.forEach(function(element, index){
        var temp = {};
        temp._id = element._id;
        temp.Time = element.Time;
        temp.courtId = element.CourtId['_id'];
        temp.court = element.CourtId['CourtName'];
        temp.courtNumber = element.CourtId['CourtNo'];
        temp.EventId= element.EventId['_id'];
        temp.EventName = element.EventId['EventName'];
        temp.Event = element.EventId['EventType'];
        temp.GameFormat = element.FormatId['FormateName'];
        temp.GameFormatId = element.FormatId['_id'];
        temp.twopointse = element.FormatId['twopointse'];
        temp.Referee = element.RefereeId['FirstName'];
        temp.RefereeId = element.RefereeId['_id'];
        temp.MatchStatus = element.MatchStatus;
        var t1 = [];
        var t2 = [];
        var taobj1 = {};
        taobj1.Name = element.TeamAPlayer1Id['FirstName'];
        taobj1.id = element.TeamAPlayer1Id['_id'];
        var tbobj1 = {};
        tbobj1.Name = element.TeamBPlayer1Id['FirstName'];
        tbobj1.id = element.TeamBPlayer1Id['_id'];
        t1.push(taobj1);
        t2.push(tbobj1);
        var taobj2 = {};
        var tbobj2 = {};
        if(element.TeamAPlayer2Id !== undefined){
          taobj2.Name = element.TeamAPlayer2Id['FirstName'];
          taobj2.id = element.TeamAPlayer2Id['_id'];
          t1.push(taobj2);
        }
        if(element.TeamBPlayer2Id !== undefined){
          tbobj2.Name = element.TeamBPlayer2Id['FirstName'];
          tbobj2.id = element.TeamBPlayer2Id['_id'];
          t2.push(tbobj2);
        }          
        temp.Team1 = {};
        temp.Team1.Players = t1;
        temp.Team2 = {};
        temp.Team2.Players = t2;
        matchsarr.push(temp);
      })
      res.status(200).send({"Matchs": matchsarr});
    }else{
      res.status(200).send("no matches found");
    }
  })
}

//reloading match service
exports.reloadrefereelogin = function(req, res){
  Sheduledmatches.find({RefereeId: req.user._id, Status: true})
  .populate({path:'CourtId', select:"_id CourtName CourtNo"})
  .populate({path:'EventId', select:'EventName EventType'})
  .populate({path:'FormatId', select:'FormateName ScoreCard twopointse'})
  .populate({path:'TeamAPlayer1Id', select:'Served FirstName _id'})
  .populate({path:'TeamAPlayer2Id', select:'Served FirstName _id'})
  .populate({path:'TeamBPlayer1Id', select:'Served FirstName _id'})
  .populate({path:'TeamBPlayer2Id', select:'Served FirstName _id'})
  .populate({path:'RefereeId', select:'FirstName _id'})
  .lean()
  .exec(function(err, matchobj){
    if(err){ return handleError(res, err); }
    if(matchobj.length > 0){
      /*if(matchobj[0]._id.MatchStatus == "Complete"){
        res.status(200).send("sorry this match has been completed");
      }else{*/
        var temp = {};
        temp._id = matchobj[0]._id;
        temp.Time = matchobj[0].Time;
        temp.courtId = matchobj[0].CourtId['_id'];
        temp.court = matchobj[0].CourtId['CourtName'];
        temp.courtNumber = matchobj[0].CourtId['CourtNo'];
        temp.EventId= matchobj[0].EventId['_id'];
        temp.EventName = matchobj[0].EventId['EventName'];
        temp.Event = matchobj[0].EventId['EventType'];
        temp.GameFormat = matchobj[0].FormatId['FormateName'];
        temp.GameFormatId = matchobj[0].FormatId['_id'];
        temp.twopointse = matchobj[0].FormatId['twopointse'];
        temp.Referee = matchobj[0].RefereeId['FirstName'];
        temp.RefereeId = matchobj[0].RefereeId['_id'];
        temp.MatchStatus = matchobj[0].MatchStatus;
        temp.GameStatus = matchobj[0].GameStatus;
        if(matchobj[0].FirstServe !== undefined){
          temp.FirstServe = matchobj[0].FirstServe;
          temp.ScoreCard = matchobj[0].ScoreCard;
        }else{
          temp.ScoreCard = matchobj[0].FormatId['ScoreCard'];
        }
        var t1 = [];
        var t2 = [];
        var taobj1 = {};
        taobj1.Name = matchobj[0].TeamAPlayer1Id['FirstName'];
        taobj1.id = matchobj[0].TeamAPlayer1Id['_id'];
        taobj1.Served = matchobj[0].TeamAPlayer1Id['Served'];
        var tbobj1 = {};
        tbobj1.Name = matchobj[0].TeamBPlayer1Id['FirstName'];
        tbobj1.id = matchobj[0].TeamBPlayer1Id['_id'];
        tbobj1.Served = matchobj[0].TeamBPlayer1Id['Served'];
        t1.push(taobj1);
        t2.push(tbobj1);
        var taobj2 = {};
        var tbobj2 = {};
        if(matchobj[0].TeamAPlayer2Id !== undefined){
          taobj2.Name = matchobj[0].TeamAPlayer2Id['FirstName'];
          taobj2.id = matchobj[0].TeamAPlayer2Id['_id'];
          taobj2.Served = matchobj[0].TeamAPlayer2Id['Served'];
          t1.push(taobj2);
        }
        if(matchobj[0].TeamBPlayer2Id !== undefined){
          tbobj2.Name = matchobj[0].TeamBPlayer2Id['FirstName'];
          tbobj2.id = matchobj[0].TeamBPlayer2Id['_id'];
          tbobj2.Served = matchobj[0].TeamBPlayer1Id['Served'];
          t2.push(tbobj2);
        }          
        temp.Team1 = {};
        temp.Team1.Players = t1;
        temp.Team2 = {};
        temp.Team2.Players = t2;
        //var token = auth.signToken(matchobj[0].RefereeId, "Referee");
        res.status(200).send({"Matchs": temp});
      //}      
    }else{
      res.status(200).send('no matches found');
    }
  })
}

//delete match service
exports.deletematch = function(req, res){
  Sheduledmatches.findOne({_id: req.params.MatchId, Status: true})
  .populate({path:"TeamAPlayer1Id", select:"_id"})
  .populate({path:"TeamBPlayer1Id", select:"_id"})
  .exec(function(err, matchdetails){
    if(err){ return handleError(res, err); }
    if(matchdetails){
      Courts.update({_id: matchdetails.CourtId, Selected: true},{$set:{Selected: false}}).exec();
      EventPlayerList.update({Player1Id: matchdetails.TeamAPlayer1Id._id, Selected: true},{$set:{Selected: false}}).exec();
      EventPlayerList.update({Player1Id: matchdetails.TeamBPlayer1Id._id, Selected: true},{$set:{Selected: false}}).exec();
      User.update({_id: matchdetails.RefereeId, Selected: true},{$set:{Selected: false}}).exec();
      Sheduledmatches.update({_id:req.params.MatchId, Status: true},{$set:{Status: false}}).exec();
      res.status(200).json("updated successfully");
    }else{
      res.status(400).json("invalid match id");
    }
  })
} 