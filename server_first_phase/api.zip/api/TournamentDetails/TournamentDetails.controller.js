'use strict';

var _ = require('lodash');
var TournamentDetails = require('./TournamentDetails.model');
var Courts = require('../../api/Courts/Courts.model');
var TournamentDetails = require('../../api/TournamentDetails/TournamentDetails.model');
var TournamentEvents = require('../../api/TournamentEvents/TournamentEvents.model');
var TournamentFormates = require('../../api/TournamentFormats/TournamentFormats.model');
var Sheduledmatches = require('../../api/SheduledMatches/SheduledMatches.model');
var ScoreBoard = require('../../api/ScoreBoard/ScoreBoard.model');
var TournamentReferees = require('../../api/TournamentReferees/TournamentReferees.model');
var Users = require('../../api/Users/Users.model');
// Get list of TournamentDetailss
exports.index = function(req, res) {
  TournamentDetails.find({TournamentOwner: req.user._id},{TournamentOwner: 1})
  .lean()
  .exec()
  .then(function(tournamentdetails){
  var id = tournamentdetails[0]._id;
  return [id];      
  })
  .then(function(result){
    return Courts.find({TournamentId: result[0]}).lean().exec()
    .then(function(Courts){
      result[1] = Courts;
      return result;
    })
  })
  .then(function(result){
    return TournamentEvents.find({TournamentId: result[0]})
    .populate({path:"EventId", select:"EventName EventType"})
    .lean()     
    .exec()
    .then(function(tournmentevents){
      tournmentevents.forEach(function(element, index){
        element.EventName = element.EventId.EventName;
        element.EventType = element.EventId.EventType;
        element.EventId = element.EventId._id;
      })
      result[2] = tournmentevents;
      return result;
    })
  })
  .then(function(result){
    return TournamentFormates.find({TournamentId: result[0]})
    .populate({path:'FormatId', select:"FormatName"})
    .lean()
    .exec()
    .then(function(tournamentformates){
      tournamentformates.forEach(function(element, index){
        element.FormatName = element.FormatId.FormatName;
        element.FormatId = element.FormatId._id;
      })
      result[3] = tournamentformates;
      return result;
    })
  })
  .then(function(result){
    return Sheduledmatches.find({TournamentId: result[0]})
    .populate({path:"EventId", select:"EventName EventType"})
    .populate({path:"FormatId", select:"FormatName"})
    .populate({path:"CourtId", select:"CourtName CourtNumber"})
    .populate({path:"TeamA_Player1_Id", select:"FirstName LastName"})
    .populate({path:"TeamA_Player2_Id", select:"FirstName LastName"})
    .populate({path:"TeamB_Player1_Id", select:"FirstName LastName"})
    .populate({path:"TeamB_Player2_Id", select:"FirstName LastName"})
    .lean()
    .exec()
    .then(function(scheduledmatches){
      result[4] = scheduledmatches;
      return result
    })
  })
  .then(function(result){
    return TournamentReferees.find({TournamentId: result[0]})
    .populate({path:"RefereeId", select:'FirstName LastName _id'})
    .lean()
    .then(function(refreeobj){
      var arr = [];
      refreeobj.forEach(function(element, index){
        var temp = {};
        temp.RefereeName = element.RefereeId.FirstName+""+element.RefereeId.LastName;
        temp.RefereeId = element.RefereeId._id;
        arr.push(temp);
      })
      result[5] = arr;
      return result;
    })
  })
  .then(function(result){
    var tempobj = {};
    tempobj.Courts = result[1];
    tempobj.Events = result[2];
    tempobj.Formats = result[3];
    tempobj.Matchs = result[4];
    tempobj.Referee = result[5];
    res.status(200).json(tempobj);
  })
};

// Get a single TournamentDetails
exports.show = function(req, res) {
  TournamentDetails.findById(req.params.id, function (err, TournamentDetails) {
    if(err) { return handleError(res, err); }
    if(!TournamentDetails) { return res.status(404).send('Not Found'); }
    return res.json(TournamentDetails);
  });
};

// Creates a new TournamentDetails in the DB.
exports.create = function(req, res) {
  TournamentDetails.create(req.body, function(err, TournamentDetails) {
    if(err) { return handleError(res, err); }
    return res.status(201).json(TournamentDetails);
  });
};

// Updates an existing TournamentDetails in the DB.
exports.update = function(req, res) {
  if(req.body._id) { delete req.body._id; }
  TournamentDetails.findById(req.params.id, function (err, TournamentDetails) {
    if (err) { return handleError(res, err); }
    if(!TournamentDetails) { return res.status(404).send('Not Found'); }
    var updated = _.merge(TournamentDetails, req.body);
    updated.save(function (err) {
      if (err) { return handleError(res, err); }
      return res.status(200).json(TournamentDetails);
    });
  });
};

// Deletes a TournamentDetails from the DB.
exports.destroy = function(req, res) {
  TournamentDetails.findById(req.params.id, function (err, TournamentDetails) {
    if(err) { return handleError(res, err); }
    if(!TournamentDetails) { return res.status(404).send('Not Found'); }
    TournamentDetails.remove(function(err) {
      if(err) { return handleError(res, err); }
      return res.status(204).send('No Content');
    });
  });
};

function handleError(res, err) {
  return res.status(500).send(err);
}